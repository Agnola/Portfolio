% Q2a

% Leave any lines of MATLAB code that are already in this file
% DO NOT clear, close or clc inside this script
% Do not forget good programming practices
%
% Your name
% Your student ID
% Date you wrote it
fprintf('\n Q2a \n\n')

%% plotting the circle and square


