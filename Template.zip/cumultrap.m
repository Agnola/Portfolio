function I = cumultrap(x,y)
% I = cumultrap(x,y)
% Written by: ???, ID: ???
% Last modified: ???
% Performs cumulative composite trapezoidal rule
%
% INPUTS:
%  - x: independent variable 
%  - y: dependent variable
% OUTPUT:
%  - I: cumulative integral of y at each x value

