% Q1c

% Leave any lines of MATLAB code that are already in this file
% DO NOT clear, close or clc inside this script
% Do not forget good programming practices
%
% Your name
% Your student ID
% Date you wrote it
fprintf('\n Q1c \n\n')

%% calculating the velocities and displacements



%% plotting the displacements and satellite image



%% calculating track length using for loop


