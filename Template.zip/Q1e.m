% Q1e

% Leave any lines of MATLAB code that are already in this file
% DO NOT clear, close or clc inside this script
% Do not forget good programming practices
%
% Your name
% Your student ID
% Date you wrote it
fprintf('\n Q1e \n\n')

%% identifying the deceleration and acceleration zones



%% plotting


