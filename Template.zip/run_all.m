% run_all.m
clear all; close all; clc; fclose all;

%% do not modify any part of this file!
% it runs each part individually
% there should be no intervention from the user
% students will lose marks if this file does not run properly

%% Question 1
%Q1a
Q1a

%Q1b is a task to write a function file

%Q1c
Q1c;

%Q1d
Q1d;

%Q1e
Q1e;

%% Question 2
%Q2a
Q2a;

%Q2a
Q2b;

%% Question 3
%Q3a
Q3a;

%Q3b
Q3b;

%Q3c
Q3c;

%Q3d
Q3d;
